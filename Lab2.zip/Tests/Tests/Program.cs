﻿using System;

namespace MyShop
{
    using System;

    // Абстрактный класс для позиций меню ресторана
    public abstract class Product
    {
        public int weight;
        public int price;

        // Методы, которые должны быть реализованы в производных классах
        public abstract void Init(int _weight, int _price); // Инициализация веса и цены
        public abstract void Read(); // Ввод данных
        public abstract void Display(); // Вывод данных
        public abstract int GetCost(); // Получение пищевой ценности
    }

    // Базовый класс BasicHelper1 для первого вспомогательного изделия
    public class BasicHelper1 : Product
    {
        public override void Init(int _weight, int _price)
        {
            weight = _weight;
            price = _price;
        }

        public override void Read()
        {
            // Ввод данных с консоли
            Console.Write("Введите массу нетто продукта BasicHelper1: ");
            weight = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите пищевую ценность за 100 грамм продукта BasicHelper1: ");
            price = Convert.ToInt32(Console.ReadLine());
        }

        public override void Display()
        {
            // Вывод данных в консоль
            Console.WriteLine($"Масса нетто продукта BasicHelper1: {weight} грамм");
            Console.WriteLine($"Пищевая ценность на 100 грамм продукта BasicHelper1: {price} калорий");
            Console.WriteLine($"Калорийность продукта BasicHelper1: {GetCost()} калорий");
        }

        public override int GetCost()
        {
            return weight * price;
        }
    }

    // Класс BasicHelper2 для второго вспомогательного продукта
    public class BasicHelper2 : Product
    {
        // Реализация методов базового класса
        public override void Init(int _weight, int _price)
        {
            weight = _weight;
            price = _price;
        }

        public override void Read()
        {
            Console.Write("Введите массу нетто продукта для BasicHelper2: ");
            weight = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите пищевую ценность за 100 грамм продукта BasicHelper2: ");
            price = Convert.ToInt32(Console.ReadLine());
        }

        public override void Display()
        {
            Console.WriteLine($"Масса нетто продукта BasicHelper2: {weight} грамм");
            Console.WriteLine($"Пищевая ценность на 100 грамм продукта BasicHelper2: {price} калорий");
            Console.WriteLine($"Калорийность продукта BasicHelper2: {GetCost()} калорий");
        }

        public override int GetCost()
        {
            return weight * price;
        }
    }

    // Класс DerivedHelper1 наследует от BasicHelper1 и добавляет новое поле
    public class DerivedHelper1 : BasicHelper1
    {
        public int derivedField1;

        // Инициализация полей базового и производного классов
        public void Init(int _weight, int _price, int _derivedField1)
        {
            base.Init(_weight, _price);
            derivedField1 = _derivedField1;
        }

        // Переопределение метода чтения данных
        public void Read()
        {
            base.Read();
            Console.Write("Введите значение для производного поля 1: ");
            derivedField1 = Convert.ToInt32(Console.ReadLine());
        }

        // Переопределение метода вывода данных
        public void Display()
        {
            base.Display();
            Console.WriteLine($"Производное поле 1: {derivedField1}");
        }

        // Переопределение метода получения калорийности
        public int GetCost()
        {
            return base.GetCost() * derivedField1;
        }
    }

    // Класс DerivedHelper2 наследует от BasicHelper2 и добавляет новое поле
    public class DerivedHelper2 : BasicHelper2
    {
        public int derivedField2;

        public void Init(int _weight, int _price, int _derivedField2)
        {
            base.Init(_weight, _price);
            derivedField2 = _derivedField2;
        }

        public void Read()
        {
            base.Read();
            Console.Write("Введите значение для производного поля 2: ");
            derivedField2 = Convert.ToInt32(Console.ReadLine());
        }

        public void Display()
        {
            base.Display();
            Console.WriteLine($"Производное поле 2: {derivedField2}");
        }

        public int GetCost()
        {
            return base.GetCost() * derivedField2;
        }
    }

    // Класс FirstDerivedProduct представляет первое продукт, состоящий из двух базовых классов
    public class FirstDerivedProduct : Product
    {
        public BasicHelper1 helper1 = new BasicHelper1();
        public BasicHelper2 helper2 = new BasicHelper2();

        public override void Init(int _weight, int _price)
        {
            helper1.Init(_weight, _price);
            helper2.Init(_weight, _price);
        }

        public override void Read()
        {
            helper1.Read();
            helper2.Read();
        }

        public override void Display()
        {
            helper1.Display();
            helper2.Display();
        }

        public override int GetCost()
        {
            return helper1.GetCost() + helper2.GetCost();
        }
    }

    // Класс SecondDerivedProduct представляет второе продукт, состоящий из двух производных классов
    public class SecondDerivedProduct : Product
    {
        public DerivedHelper1 helper1 = new DerivedHelper1();
        public DerivedHelper2 helper2 = new DerivedHelper2();

        public override void Init(int _weight, int _price)
        {
            helper1.Init(_weight, _price, 2);
            helper2.Init(_weight, _price, 2);
        }

        public override void Read()
        {
            helper1.Read();
            helper2.Read();
        }

        public override void Display()
        {
            helper1.Display();
            helper2.Display();
        }

        public override int GetCost()
        {
            return helper1.GetCost() + helper2.GetCost();
        }
    }

    // Класс ThirdDerivedProduct представляет третий продукт, состоящий из базового и производного классов
    public class ThirdDerivedProduct : Product
    {
        public BasicHelper1 helper1 = new BasicHelper1();
        public DerivedHelper2 helper2 = new DerivedHelper2();

        public override void Init(int _weight, int _price)
        {
            helper1.Init(_weight, _price);
            helper2.Init(_weight, _price, 2);
        }

        public override void Read()
        {
            helper1.Read();
            helper2.Read();
        }

        public override void Display()
        {
            helper1.Display();
            helper2.Display();
        }

        public override int GetCost()
        {
            return helper1.GetCost() + helper2.GetCost();
        }
    }

    // Класс ProductStore представляет магазин с тремя типами блюд и их количеством
    public class ProductStore
    {
        public FirstDerivedProduct meal1 = new FirstDerivedProduct();
        public SecondDerivedProduct meal2 = new SecondDerivedProduct();
        public ThirdDerivedProduct meal3 = new ThirdDerivedProduct();

        public int quantity1;
        public int quantity2;
        public int quantity3;
        public int drinks;

        // Метод для инициализации данных о количестве и стоимости напитков
        public void Init(int _quantity1, int _quantity2, int _quantity3, int _drinks, int _weight1, int _price1, int _weight2, int _price2, int _weight3, int _price3)
        {
            quantity1 = _quantity1;
            quantity2 = _quantity2;
            quantity3 = _quantity3;
            drinks = _drinks;

            meal1.Init(_weight1, _price1);
            meal2.Init(_weight2, _price2);
            meal3.Init(_weight3, _price3);
        }

        // Метод для ввода данных о количестве и стоимости блюд
        public void Read()
        {
            Console.Write("Введите количество товаров первого типа: ");
            quantity1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите количество товаров второго типа: ");
            quantity2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите количество товаров третьего типа: ");
            quantity3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите количество напитков: ");
            drinks = Convert.ToInt32(Console.ReadLine());

            meal1.Read();
            meal2.Read();
            meal3.Read();
        }

        // Метод для отображения информации о калорийности блюд
        public void Display()
        {
            Console.WriteLine($"Общая калорийность блюд: {(meal1.GetCost() * quantity1) + (meal2.GetCost() * quantity2) + (meal3.GetCost() * quantity3) + drinks} калорий");

            meal1.Display();
            meal2.Display();
            meal3.Display();
        }
    }

    class MyJewelry
    {
        static void Main(string[] args)
        {
            // Создание объекта магазин и инициализация данных
            ProductStore ProductStore = new ProductStore();
            ProductStore.Init(10, 20, 30, 500, 40, 500, 35, 120, 55, 200);

            // Ввод данных о количестве и калорийности блюд
            ProductStore.Read();

            // Отображение информации о калорийности блюд
            ProductStore.Display();

            // Ожидание нажатия клавиши для завершения программы
            Console.ReadKey();
        }
    }

}